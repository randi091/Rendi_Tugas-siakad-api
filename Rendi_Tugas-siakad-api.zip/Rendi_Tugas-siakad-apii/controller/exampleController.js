const exampleController = {}

/*
    this is auto generate example, you can continue 

*/
exampleController.index = async(req,res) => {
    res.json({
        message : "Hello exampleController"
    })
}

module.exports = exampleController

